import gradio as gr
import Core

# Initialize your AI agent (make sure to input your OpenAI API key)
api_key = input("Enter your OpenAI API key: ")
agent = Core.AIAgent(api_key)


# ----------------- Functions ----------------- #

def analyze_protein(pdb_id):
    try:
        result = agent.analyze_target_protein(pdb_id)
        summary = result['summary']
        analysis = result['analysis']
        return summary, analysis
    except Exception as e:
        return f"Error fetching protein: {e}", ""


def evaluate_compound(pdb_id, smiles):
    try:
        result = agent.evaluate_compound(pdb_id, smiles)
        return result
    except Exception as e:
        return f"Error evaluating compound: {e}"


def optimize_compound(smiles, goals):
    try:
        result = agent.optimize_compound(smiles, goals)
        return result
    except Exception as e:
        return f"Error optimizing compound: {e}"
    
def visualize_compound(smiles):
    try:
        img = Core.CompoundAnalyzer.visualize_smiles(smiles)
        return img
    except Exception as e:
        return f"Error visualizing compound: {e}"


# ----------------- Gradio UI ----------------- #

with gr.Blocks() as demo:
    gr.Markdown("## AI Drug Design Platform")

    with gr.Tab("Protein Analysis"):
        pdb_input = gr.Textbox(label="Enter PDB ID", placeholder="e.g., 1AZ5")
        protein_summary = gr.Textbox(label="Protein Summary", lines=25, interactive=False)
        protein_analysis = gr.Textbox(label="Analysis", lines=35, interactive=False)
        submit_protein = gr.Button("Analyze Protein")
        submit_protein.click(analyze_protein, inputs=pdb_input, outputs=[protein_summary, protein_analysis])

    with gr.Tab("Compound Evaluation"):
        pdb_input_eval = gr.Textbox(label="Target Protein PDB ID", placeholder="e.g., 6LU7")
        compound_input = gr.Textbox(label="Compound SMILES", placeholder="e.g., CC(=O)OC1=CC=CC=C1C(=O)O")
        compound_output = gr.Textbox(label="Evaluation Result", lines=35, interactive=False)
        submit_eval = gr.Button("Evaluate Compound")
        submit_eval.click(evaluate_compound, inputs=[pdb_input_eval, compound_input], outputs=compound_output)

    with gr.Tab("Compound Optimization"):
        compound_input_opt = gr.Textbox(label="Compound SMILES", placeholder="e.g., CC(=O)OC1=CC=CC=C1C(=O)O")
        goals_input = gr.Textbox(label="Optimization Goals", placeholder="Increase solubility, reduce lipophilicity")
        optimization_output = gr.Textbox(label="Optimization Result", lines=35, interactive=False)
        submit_opt = gr.Button("Optimize Compound")
        submit_opt.click(optimize_compound, inputs=[compound_input_opt, goals_input], outputs=optimization_output)
        
    with gr.Tab("Compound Visualization"):
        smiles_input_vis = gr.Textbox(label="Compound SMILES", placeholder="e.g., C1=CC=CC=C1")
        img_output = gr.Image(label="Molecule Structure")
        submit_vis = gr.Button("Visualize Compound")
        submit_vis.click(visualize_compound, inputs=smiles_input_vis, outputs=img_output)

demo.launch(share=True)